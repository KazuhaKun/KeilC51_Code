#ifndef__DELAY_H__
#define__DELAY_H__

void Delay(unsigned int xms);

#endif
