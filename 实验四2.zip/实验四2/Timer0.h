#ifndef__TIMER0_H__
#define__TIMER0_H__



void Timer0Init(void);



#endif