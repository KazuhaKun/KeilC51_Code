#ifndef __MAIN_H__
#define __MAIN_H__ 

extern unsigned char Time_5s_Count;
extern bit Flag_500ms_Task;
extern bit Flag_1s_Task;
extern bit Flag_5s_Task;
extern bit Flag_100ms_Task;
extern char Temp_State;
extern bit Flag_750ms_Ready;
#endif