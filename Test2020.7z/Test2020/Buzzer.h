#ifndef __BUZZER_H__
#define __BUZZER_H__

void Buzzer_Time(unsigned int ms);
void Buzzer_Alarm_3s(void);

#endif